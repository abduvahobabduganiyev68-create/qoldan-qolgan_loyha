# Qo'ldan-qo'lga — marketplace frontend demo

## Ishga tushirish
1. `qoldan_qolga_marketplace` papkasini oching.
2. `index.html` faylini Chrome'da oching. Eng yaxshi natija uchun VS Code Live Server ishlating.
3. Tashqi rasmlar va Google Fonts internet orqali yuklanadi.

## Demo ichidagi funksiyalar
- O'zbekcha marketplace bosh sahifasi
- Yorug'/qorong'u rejim (localStorage'da eslab qoladi)
- Kategoriyalar, qidiruv, hudud/holat/narx filtrlari, saralash
- E'lon kartalari va tafsilot modali
- Sevimlilarga qo'shish/o'chirish
- Email/parol demo ro'yxatdan o'tish va kirish (localStorage)
- Mobil pastki navigatsiya
- Xavfsiz savdo eslatmalari
- Responsiv dizayn

## Muhim
Bu frontend prototip. Login parollari localStorage'da demo maqsadida saqlanadi — haqiqiy saytga bunday autentifikatsiyani joylashtirmang. Google tugmasi hozircha demo ogohlantirishini beradi; haqiqiy Google OAuth, xavfsiz auth, ma'lumotlar bazasi, chat, sotuvchi e'lon yaratishi va admin huquqlari keyingi bosqichda Supabase/server bilan amalga oshirilishi kerak.
