/* Umumiy UI, tema, modallar, auth demo va sevimlilar */
(() => {
  const $ = id => document.getElementById(id);
  const THEME_KEY = "qoldanqolga.theme";
  const USERS_KEY = "qoldanqolga.users";
  const SESSION_KEY = "qoldanqolga.session";
  const FAV_KEY = "qoldanqolga.favorites";
  window.QQ = window.QQ || {};
  QQ.$ = $;
  QQ.money = n => new Intl.NumberFormat("uz-UZ",{maximumFractionDigits:0}).format(Number(n)||0);
  QQ.escape = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  QQ.getFavorites = () => {try{return JSON.parse(localStorage.getItem(FAV_KEY)||"[]")}catch{return []}};
  QQ.setFavorites = arr => localStorage.setItem(FAV_KEY,JSON.stringify(arr));
  QQ.isFavorite = id => QQ.getFavorites().includes(String(id));
  QQ.toggleFavorite = id => {let a=QQ.getFavorites();id=String(id);a=a.includes(id)?a.filter(x=>x!==id):[...a,id];QQ.setFavorites(a);updateFavoriteCount();return a.includes(id)};
  QQ.getSession = () => {try{return JSON.parse(localStorage.getItem(SESSION_KEY)||"null")}catch{return null}};
  QQ.setSession = user => {localStorage.setItem(SESSION_KEY,JSON.stringify(user));updateAuthButton()};
  QQ.toast = message => {const el=document.createElement("div");el.className="toast";el.innerHTML=`<span class="toast-icon">✓</span><span>${QQ.escape(message)}</span>`;$("toastRegion").appendChild(el);setTimeout(()=>el.remove(),3200)};
  function updateFavoriteCount(){$("favoriteCount").textContent=QQ.getFavorites().length}
  function updateAuthButton(){const user=QQ.getSession();$("openAuth").innerHTML=user?`<span>${QQ.escape((user.name||user.email||"U").slice(0,1).toUpperCase())}</span>`:"<span>☺</span>";$("openAuth").title=user?user.email:"Kirish";}
  function setTheme(theme){document.documentElement.dataset.theme=theme;localStorage.setItem(THEME_KEY,theme);$("themeIcon").textContent=theme==="dark"?"☀":"☾";document.querySelector('meta[name="theme-color"]').content=theme==="dark"?"#101a19":"#f5f8f7"}
  const savedTheme=localStorage.getItem(THEME_KEY)||"light";setTheme(savedTheme);
  $("themeToggle").addEventListener("click",()=>setTheme(document.documentElement.dataset.theme==="dark"?"light":"dark"));
  function openModal(html){$("modalContent").innerHTML=html;$("modalBackdrop").classList.remove("hidden");document.body.style.overflow="hidden"}
  function closeModal(){$("modalBackdrop").classList.add("hidden");$("modalContent").innerHTML="";document.body.style.overflow=""}
  $("modalClose").addEventListener("click",closeModal);$("modalBackdrop").addEventListener("click",e=>{if(e.target.id==="modalBackdrop")closeModal()});document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
  QQ.openModal=openModal;QQ.closeModal=closeModal;
  function authModal(mode="login"){
    const signup=mode==="signup";
    openModal(`<h2 id="modalTitle">${signup?"Hisob yarating":"Xush kelibsiz!"}</h2><p class="modal-subtitle">${signup?"Qo'ldan-qo'lga hamjamiyatiga qo'shiling.":"E'lon joylash va sevimlilarni saqlash uchun tizimga kiring."}</p><form id="authForm">${signup?`<label class="form-field">Ismingiz<input name="name" required minlength="2" placeholder="Ism Familiya"></label>`:""}<label class="form-field">Email manzil<input name="email" type="email" required autocomplete="email" placeholder="siz@example.com"></label><label class="form-field">Parol<input name="password" type="password" required minlength="6" autocomplete="${signup?"new-password":"current-password"}" placeholder="Kamida 6 ta belgi"></label><button class="button button-primary" type="submit">${signup?"Ro'yxatdan o'tish":"Kirish"} →</button></form><div class="form-divider">yoki</div><button class="google-button" id="googleDemo"><span class="google-g">G</span> Google bilan davom etish</button><p class="modal-switch">${signup?"Hisobingiz bormi?":"Hali hisobingiz yo'qmi?"} <button id="switchAuth">${signup?"Kirish":"Ro'yxatdan o'tish"}</button></p><p class="modal-switch">Demo: ma'lumotlar faqat ushbu brauzerda saqlanadi.</p>`);
    $("switchAuth").addEventListener("click",()=>authModal(signup?"login":"signup"));
    $("googleDemo").addEventListener("click",()=>QQ.toast("Google OAuth demo rejimida ishlamaydi. Haqiqiy Google kirishi uchun Supabase OAuth sozlash kerak."));
    $("authForm").addEventListener("submit",e=>{
      e.preventDefault();const fd=new FormData(e.currentTarget),email=String(fd.get("email")).trim().toLowerCase(),password=String(fd.get("password")),name=String(fd.get("name")||email.split("@")[0]).trim();
      let users=[];try{users=JSON.parse(localStorage.getItem(USERS_KEY)||"[]")}catch{}
      if(signup){if(users.some(u=>u.email===email)){QQ.toast("Bu email bilan hisob mavjud.");return}users.push({email,password,name});localStorage.setItem(USERS_KEY,JSON.stringify(users));QQ.setSession({email,name});closeModal();QQ.toast("Hisob yaratildi! Demo rejimga xush kelibsiz.");}
      else{const user=users.find(u=>u.email===email&&u.password===password);if(!user){QQ.toast("Email yoki parol xato. Demo uchun avval ro'yxatdan o'ting.");return}QQ.setSession({email:user.email,name:user.name});closeModal();QQ.toast("Muvaffaqiyatli kirdingiz!")}
    });
  }
  $("openAuth").addEventListener("click",()=>{const u=QQ.getSession();if(u){openModal(`<h2 id="modalTitle">Profil</h2><p class="modal-subtitle">Siz demo rejimda kirdingiz.</p><div class="form-field">Ism: <b>${QQ.escape(u.name)}</b></div><div class="form-field">Email: <b>${QQ.escape(u.email)}</b></div><button id="logoutBtn" class="button button-primary">Hisobdan chiqish</button>`);$("logoutBtn").addEventListener("click",()=>{localStorage.removeItem(SESSION_KEY);updateAuthButton();closeModal();QQ.toast("Hisobdan chiqdingiz.")})}else authModal("login")});
  $("openCreate").addEventListener("click",()=>{if(!QQ.getSession()){QQ.toast("E'lon joylash uchun avval demo hisob yarating.");authModal("signup");return}QQ.toast("Keyingi bosqichda e'lon yaratish formasini ulaymiz.")});
  $("heroSell").addEventListener("click",()=>$("openCreate").click());$("bannerSell").addEventListener("click",()=>$("openCreate").click());$("mobileAdd").addEventListener("click",()=>$("openCreate").click());
  $("headerFavorites").addEventListener("click",()=>{if(window.QQListings)QQListings.showFavorites();else QQ.toast("Sevimlilar yuklanmoqda.")});
  $("browseListings").addEventListener("click",()=>$("listingsSection").scrollIntoView({behavior:"smooth"}));
  $("allCategories").addEventListener("click",()=>{if(window.QQListings)QQListings.setCategory("all");$("listingsSection").scrollIntoView({behavior:"smooth"})});
  $("safetyMore").addEventListener("click",e=>{e.preventDefault();openModal(`<h2 id="modalTitle">Xavfsiz savdo qoidalari</h2><p class="modal-subtitle">Qo'ldan-qo'lga — xaridor va sotuvchini bog'lovchi demo platforma.</p><ul class="safety-rules"><li>Buyumni ko'rmasdan va sotuvchini tekshirmasdan oldindan pul yubormang.</li><li>Uchrashuv uchun odamlar bor, xavfsiz jamoat joyini tanlang.</li><li>Buyumni ishlashini tekshirib, narx va holatini kelishib oling.</li><li>SMS kod, karta PIN-kodi yoki maxfiy parolingizni hech kimga bermang.</li><li>Shubhali e'lonlarni platforma administratoriga xabar qiling.</li></ul><button class="button button-primary" id="safetyDone">Tushunarli</button>`);$("safetyDone").addEventListener("click",closeModal)});
  $("footerSafety").addEventListener("click",e=>{$("safetyMore").click();e.preventDefault()});$("footerAbout").addEventListener("click",e=>{e.preventDefault();openModal(`<h2 id="modalTitle">Qo'ldan-qo'lga</h2><p class="modal-subtitle">Yaxshi buyumlar yangi egasini topishi uchun yaratilgan mahalliy marketplace demo. Hozirgi versiya prototip bo'lib, ma'lumotlar brauzeringizda saqlanadi.</p><button class="button button-primary" id="aboutDone">Davom etish</button>`);$("aboutDone").addEventListener("click",closeModal)});
  document.querySelectorAll("[data-mobile-view]").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".mobile-nav-item").forEach(b=>b.classList.toggle("active",b===btn));const view=btn.dataset.mobileView;if(view==="home")window.scrollTo({top:0,behavior:"smooth"});if(view==="search"){window.scrollTo({top:$("listingsSection").offsetTop-75,behavior:"smooth"});setTimeout(()=>$("listingSearch").focus(),400)}if(view==="favorites")QQListings?.showFavorites();if(view==="profile")$("openAuth").click()}));
  $("yearNow").textContent=new Date().getFullYear();updateFavoriteCount();updateAuthButton();
})();