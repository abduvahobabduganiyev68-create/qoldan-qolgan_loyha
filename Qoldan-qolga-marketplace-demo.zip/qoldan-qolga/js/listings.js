/* E'lonlar, qidiruv, filtrlar, saralash, sevimlilar va kartochkalar */
(() => {
  const $ = id => document.getElementById(id);
  const items = [
    {id:"p101",title:"Samsung 24” monitor — tiniq tasvir",category:"Elektronika",price:850000,condition:"Yaxshi",city:"Toshkent",seller:"Aziz Karimov",rating:4.9,views:124,age:"Bugun",description:"Ofis va o'qish uchun qulay monitor. Tasviri tiniq, barcha portlari ishlaydi. Kabeli bilan beriladi.",image:"https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p102",title:"Minimalist yog'och jurnal stoli",category:"Uy va mebel",price:420000,condition:"Yaxshi",city:"Samarqand",seller:"Madina S.",rating:5.0,views:89,age:"2 soat oldin",description:"Mustahkam va ixcham stol. Kichik xona yoki mehmonxona uchun mos. Yengil ishlatilgan.",image:"https://images.unsplash.com/photo-1533090481720-856c6e3c1fdc?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p103",title:"Simsiz quloqchin, toza ovoz",category:"Elektronika",price:230000,condition:"Yangidek",city:"Toshkent",seller:"Javohir A.",rating:4.8,views:67,age:"3 soat oldin",description:"Kam ishlatilgan simsiz quloqchin. Batareyasi yaxshi ushlaydi, qutisi bor.",image:"https://images.unsplash.com/photo-150З?auto=format&fit=crop&w=700&q=85",fallback:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=700&q=85",negotiable:false},
    {id:"p104",title:"Shahar uchun velosiped",category:"Sport va hordiq",price:1150000,condition:"Yaxshi",city:"Farg'ona",seller:"Sardor B.",rating:4.7,views:203,age:"Kecha",description:"Yurishi ravon, tormozlari soz. Kundalik qatnov va sayr uchun qulay.",image:"https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p105",title:"Yumshoq kreslo — qulay dam olish",category:"Uy va mebel",price:980000,condition:"O'rtacha",city:"Toshkent",seller:"Dilnoza R.",rating:4.9,views:156,age:"Kecha",description:"Qulay kreslo, matosida mayda foydalanish izlari bor. Uy yoki ish xonasi uchun.",image:"https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p106",title:"Mexanik klaviatura — RGB yoritish",category:"Elektronika",price:360000,condition:"Yaxshi",city:"Andijon",seller:"Bekzod M.",rating:4.6,views:72,age:"1 kun oldin",description:"Yozish va o'yin uchun mexanik klaviatura. Tugmalari soz, yoritish rejimlari ishlaydi.",image:"https://images.unsplash.com/photo-158킬?auto=format&fit=crop&w=700&q=85",fallback:"https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=700&q=85",negotiable:false},
    {id:"p107",title:"Kundalik ryukzak, 25 litr",category:"Kiyim va aksessuar",price:190000,condition:"Yangidek",city:"Buxoro",seller:"Malika T.",rating:5.0,views:43,age:"1 kun oldin",description:"Noutbuk uchun bo'limi bor, yengil va qulay ryukzak. Safar va o'qish uchun.",image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p108",title:"Elektr burg'ulash asbobi",category:"Asboblar",price:470000,condition:"Yaxshi",city:"Namangan",seller:"Usta Olim",rating:4.8,views:111,age:"2 kun oldin",description:"Uy ta'miri uchun elektr drel. Ishlash holati yaxshi, bir nechta uchlari bilan.",image:"https://images.unsplash.com/photo-1504148455328-c376907d081c?auto=format&fit=crop&w=700&q=85",negotiable:false},
    {id:"p109",title:"Android telefon, 128 GB",category:"Elektronika",price:1450000,condition:"Yaxshi",city:"Toshkent",seller:"Shahzod N.",rating:4.9,views:314,age:"2 kun oldin",description:"Xotirasi 128 GB, ekrani yaxshi, kundalik foydalanishga tayyor. G'ilofi bilan.",image:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p110",title:"Kitoblar to'plami — 6 dona",category:"Uy va mebel",price:120000,condition:"Yaxshi",city:"Samarqand",seller:"Nodira Q.",rating:4.9,views:32,age:"3 kun oldin",description:"O'qib bo'lingan, yaxshi saqlangan kitoblar. Birgalikda sotiladi.",image:"https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=700&q=85",negotiable:true},
    {id:"p111",title:"Sport gantellari, juftlik",category:"Sport va hordiq",price:250000,condition:"Yaxshi",city:"Farg'ona",seller:"Akmal J.",rating:4.7,views:58,age:"3 kun oldin",description:"Uy sharoitida mashq qilish uchun. Tutqichlari qulay, yaxshi holatda.",image:"https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=700&q=85",negotiable:false},
    {id:"p112",title:"Stol chirog'i — zamonaviy dizayn",category:"Uy va mebel",price:175000,condition:"Yangidek",city:"Andijon",seller:"Sevara K.",rating:4.8,views:61,age:"4 kun oldin",description:"Ish stoli yoki yotoqxona uchun ixcham chiroq. Yorug'ligi yoqimli.",image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=700&q=85",negotiable:true}
  ];
  // Replace any malformed remote image URLs with reliable fallback images.
  items[2].image=items[2].fallback;
  items[5].image=items[5].fallback;
  let activeCategory="all",favoritesOnly=false,visibleLimit=8;
  const conditionLabel={ "Yangidek":"Yangidek","Yaxshi":"Yaxshi","O'rtacha":"O'rtacha","Ta'mir kerak":"Ta'mir kerak" };
  function getFilters(){
    return {q:$("listingSearch").value.trim().toLowerCase(),city:$("cityFilter").value,condition:$("conditionFilter").value,min:Number($("minPrice").value)||0,max:Number($("maxPrice").value)||Infinity,sort:$("sortSelect").value};
  }
  function filtered(){
    const f=getFilters();let arr=items.filter(p=>{
      const text=(p.title+" "+p.description+" "+p.category).toLowerCase();
      return (!f.q||text.includes(f.q))&&(activeCategory==="all"||p.category===activeCategory)&&(f.city==="all"||p.city===f.city)&&(f.condition==="all"||p.condition===f.condition)&&p.price>=f.min&&p.price<=f.max&&(!favoritesOnly||QQ.isFavorite(p.id));
    });
    if(f.sort==="cheap")arr.sort((a,b)=>a.price-b.price);else if(f.sort==="expensive")arr.sort((a,b)=>b.price-a.price);else arr.sort((a,b)=>Number(b.id.slice(1))-Number(a.id.slice(1)));
    return arr;
  }
  function productCard(p){
    const fav=QQ.isFavorite(p.id);
    return `<article class="product-card" data-product="${p.id}"><div class="product-image-wrap" data-open-product="${p.id}"><img class="product-image" loading="lazy" src="${QQ.escape(p.image)}" alt="${QQ.escape(p.title)}" onerror="this.onerror=null;this.src='https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=700&q=80'"><span class="product-condition">${QQ.escape(conditionLabel[p.condition]||p.condition)}</span><button class="favorite-button ${fav?"is-favorite":""}" data-favorite="${p.id}" aria-label="${fav?"Sevimlilardan olib tashlash":"Sevimlilarga qo'shish"}">${fav?"♥":"♡"}</button></div><div class="product-content"><div class="product-category">${QQ.escape(p.category)}</div><h3 class="product-title" data-open-product="${p.id}">${QQ.escape(p.title)}</h3><p class="product-description">${QQ.escape(p.description)}</p><div class="product-price">${QQ.money(p.price)} <small>so'm</small></div><div class="product-meta"><span class="product-location">⌖ ${QQ.escape(p.city)}</span><span class="product-time">${QQ.escape(p.age)}</span></div><div class="product-seller"><span class="seller-avatar">${QQ.escape(p.seller.split(/\s+/).map(s=>s[0]).slice(0,2).join("").toUpperCase())}</span><span class="seller-name">${QQ.escape(p.seller)}</span><span class="seller-rating">★ ${p.rating.toFixed(1)}</span></div></div></article>`;
  }
  function render(){
    const arr=filtered(),shown=arr.slice(0,visibleLimit);
    $("productGrid").innerHTML=shown.length?shown.map(productCard).join(""):`<div class="empty-state"><span>⌕</span><h3>${favoritesOnly?"Sevimlilar hali bo'sh":"E'lon topilmadi"}</h3><p>${favoritesOnly?"Yoqtirgan buyumlaringizni ♡ tugmasi bilan saqlang.":"Filtrlarni o'zgartirib ko'ring yoki boshqa so'z bilan qidiring."}</p><button class="button button-outline" id="emptyClear">Filtrlarni tozalash</button></div>`;
    $("listingCount").textContent=arr.length;
    $("resultsInfo").textContent=arr.length?`${shown.length} / ${arr.length} ta e'lon ko'rsatilmoqda`:"Mos e'lonlar yo'q";
    $("loadMore").classList.toggle("hidden",shown.length>=arr.length||arr.length===0);
    $("listingsTitle").innerHTML=favoritesOnly?'Sevimli e’lonlar <span class="heading-count" id="listingCount">'+arr.length+'</span>':'Yangi e’lonlar <span class="heading-count" id="listingCount">'+arr.length+'</span>';
    $("activeFilters").innerHTML=[activeCategory!=="all"?activeCategory:null,getFilters().city!=="all"?getFilters().city:null,getFilters().condition!=="all"?getFilters().condition:null,getFilters().q?`“${getFilters().q}”`:null].filter(Boolean).map(x=>`<span class="filter-chip">${QQ.escape(x)} <button data-remove-filter="${QQ.escape(x)}" aria-label="Filtrni olib tashlash">×</button></span>`).join("");
    document.querySelectorAll(".category-card").forEach(b=>b.classList.toggle("selected",b.dataset.category===activeCategory));
  }
  function resetFilters(){activeCategory="all";favoritesOnly=false;visibleLimit=8;$("listingSearch").value="";$("cityFilter").value="all";$("conditionFilter").value="all";$("minPrice").value="";$("maxPrice").value="";$("sortSelect").value="newest";render()}
  function setCategory(c){activeCategory=c;favoritesOnly=false;visibleLimit=8;render()}
  function showFavorites(){favoritesOnly=true;activeCategory="all";visibleLimit=items.length;render();$("listingsSection").scrollIntoView({behavior:"smooth"})}
  function detailModal(id){
    const p=items.find(x=>x.id===id);if(!p)return;const fav=QQ.isFavorite(id);
    QQ.openModal(`<div class="detail-image" style="height:220px;border-radius:14px;overflow:hidden;margin-bottom:18px;background:var(--surface-2)"><img src="${QQ.escape(p.image)}" alt="${QQ.escape(p.title)}" style="width:100%;height:100%;object-fit:cover"></div><span class="eyebrow">${QQ.escape(p.category)} · ${QQ.escape(p.city)}</span><h2 id="modalTitle" style="margin-top:8px">${QQ.escape(p.title)}</h2><p class="modal-subtitle">${QQ.escape(p.description)}</p><div style="font:800 24px Manrope,sans-serif;margin:12px 0">${QQ.money(p.price)} so'm ${p.negotiable?'<span style="font:600 10px DM Sans,sans-serif;color:var(--teal)">· Savdolashish mumkin</span>':''}</div><div style="display:flex;align-items:center;gap:10px;padding:12px;background:var(--surface-2);border-radius:12px;margin-bottom:14px"><span class="seller-avatar" style="width:36px;height:36px">${QQ.escape(p.seller.split(/\s+/).map(s=>s[0]).slice(0,2).join("").toUpperCase())}</span><div><b style="font-size:11px">${QQ.escape(p.seller)}</b><div style="font-size:10px;color:var(--muted);margin-top:3px">★ ${p.rating.toFixed(1)} · Demo sotuvchi</div></div></div><div style="font-size:10px;color:var(--muted);line-height:1.7;margin-bottom:15px">Holati: <b>${QQ.escape(p.condition)}</b> · Joylashuv: <b>${QQ.escape(p.city)}</b><br>Demo e'lon: sotuvchi bilan bog'lanish funksiyasi keyingi bosqichda ulanadi.</div><div style="padding:12px;background:var(--teal-soft);color:var(--teal);border-radius:10px;font-size:10px;line-height:1.6;margin-bottom:10px">Xavfsizlik: buyumni tekshirmasdan oldindan pul o'tkazmang. Uchrashuvni xavfsiz jamoat joyida belgilang.</div><button class="button button-primary" id="detailFavorite">${fav?"♥ Sevimlilardan olib tashlash":"♡ Sevimlilarga qo'shish"}</button><button class="button button-outline" id="detailShare">Ulashish ↗</button>`);
    $("detailFavorite").addEventListener("click",()=>{const added=QQ.toggleFavorite(id);render();detailModal(id);QQ.toast(added?"Sevimlilarga qo'shildi.":"Sevimlilardan olib tashlandi.")});
    $("detailShare").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(location.href.split("#")[0]+"#"+id);QQ.toast("Sahifa manzili nusxalandi.")}catch{QQ.toast("Ulashish uchun brauzer manzilini nusxalang.")}});
  }
  $("productGrid").addEventListener("click",e=>{
    const fav=e.target.closest("[data-favorite]");if(fav){e.stopPropagation();const added=QQ.toggleFavorite(fav.dataset.favorite);render();QQ.toast(added?"Sevimlilarga qo'shildi.":"Sevimlilardan olib tashlandi.");return}
    const open=e.target.closest("[data-open-product]");if(open)detailModal(open.dataset.openProduct);
    if(e.target.id==="emptyClear")resetFilters();
  });
  $("categoryList").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(b)setCategory(b.dataset.category)});
  ["listingSearch","cityFilter","conditionFilter","minPrice","maxPrice","sortSelect"].forEach(id=>$(id).addEventListener(id==="listingSearch"?"input":"change",()=>{visibleLimit=8;favoritesOnly=false;render()}));
  $("clearFilters").addEventListener("click",resetFilters);
  $("loadMore").addEventListener("click",()=>{visibleLimit+=4;render()});
  $("headerSearchForm").addEventListener("submit",e=>{e.preventDefault();$("listingSearch").value=$("headerSearch").value;favoritesOnly=false;visibleLimit=8;render();$("listingsSection").scrollIntoView({behavior:"smooth"})});
  $("headerSearch").addEventListener("input",()=>{$("listingSearch").value=$("headerSearch").value;favoritesOnly=false;visibleLimit=8;render()});
  $("activeFilters").addEventListener("click",e=>{const b=e.target.closest("[data-remove-filter]");if(!b)return;const x=b.dataset.removeFilter;if(x===activeCategory)activeCategory="all";if(x===$("cityFilter").value)$("cityFilter").value="all";if(x===$("conditionFilter").value)$("conditionFilter").value="all";if(x===`“${$("listingSearch").value}”`)$("listingSearch").value="";render()});
  QQListings={setCategory,showFavorites,render,items};
  render();
})();